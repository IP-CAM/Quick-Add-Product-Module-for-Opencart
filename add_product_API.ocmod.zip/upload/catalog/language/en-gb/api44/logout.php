<?php
// Text
$_['text_success'] = 'you loged out successfuly!';

// Error
$_['error']     = 'Warning: failed logout !';
