<?php
// Text
$_['text_success'] = 'Success: logged in successfully!';

// Error
$_['error_ip']     = 'Warning: Your IP %s is not allowed to access !';
$_['error_app']     = 'Warning: Your application is not valid!';
$_['error_cre']     = 'Warning: invalid input check your credentials';