<?php
// Text
$_['text_success'] = 'Success: You have add products!';

// Error
$_['error_product']     = 'Error: Product add !';
$_['error_directory']  = 'Warning: Directory does not exist!';
$_['error_filename']   = 'Warning: Filename must be between 3 and 255!';
$_['error_filetype']   = 'Warning: Incorrect file type!';
$_['error_filesize']   = 'Warning: Incorrect file size!';
$_['error_upload']     = 'Warning: File could not be uploaded for an unknown reason!';